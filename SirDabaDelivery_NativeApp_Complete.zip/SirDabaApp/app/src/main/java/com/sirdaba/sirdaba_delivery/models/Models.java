package com.sirdaba.sirdaba_delivery.models;

import com.google.gson.annotations.SerializedName;
import java.util.List;

// ── Base ──────────────────────────────────────────────────────────
public class BaseResponse {
    public boolean success;
    public String message;
}

// ── JWT ───────────────────────────────────────────────────────────
class JwtResponse {
    public boolean success;
    @SerializedName("data")
    public JwtData data;

    public static class JwtData {
        public String token;
        @SerializedName("user_email")
        public String userEmail;
        @SerializedName("user_nicename")
        public String userNicename;
        @SerializedName("user_display_name")
        public String userDisplayName;
    }
}

// ── Bootstrap ─────────────────────────────────────────────────────
class BootstrapResponse {
    public boolean success;
    public BootstrapData data;

    public static class BootstrapData {
        @SerializedName("site_url")        public String siteUrl;
        @SerializedName("site_name")       public String siteName;
        @SerializedName("nonce")           public String nonce;
        @SerializedName("rest_base")       public String restBase;
        @SerializedName("ajax_url")        public String ajaxUrl;
        @SerializedName("device_token_url") public String deviceTokenUrl;
        public PushConfig push;
    }

    public static class PushConfig {
        public boolean enabled;
        @SerializedName("native_enabled")       public boolean nativeEnabled;
        @SerializedName("firebase_native")      public FirebaseNative firebaseNative;
    }

    public static class FirebaseNative {
        @SerializedName("apiKey")            public String apiKey;
        @SerializedName("projectId")         public String projectId;
        @SerializedName("messagingSenderId") public String messagingSenderId;
        @SerializedName("android_app_id")    public String androidAppId;
        @SerializedName("appId")             public String appId;
        @SerializedName("storageBucket")     public String storageBucket;
    }
}

// ── User ──────────────────────────────────────────────────────────
class UserResponse {
    public boolean success;
    public UserData data;

    public static class UserData {
        public int id;
        @SerializedName("full_name")     public String fullName;
        public String name;
        public String email;
        public String phone;
        public String city;
        public String address;
        @SerializedName("user_type")     public String userType;
        @SerializedName("is_approved")   public int isApproved;
        @SerializedName("wallet_balance") public double walletBalance;
        @SerializedName("profile_image") public String profileImage;
        public String nonce;
        public String status;
    }
}

// ── Login ─────────────────────────────────────────────────────────
class LoginResponse {
    public boolean success;
    public String message;
    public UserPayload user;
    public String nonce;
    @SerializedName("jwt_token") public String jwtToken;

    public static class UserPayload {
        public int id;
        @SerializedName("full_name") public String fullName;
        public String email;
        public String phone;
        public String city;
        @SerializedName("user_type") public String userType;
        @SerializedName("wallet_balance") public double walletBalance;
        @SerializedName("is_approved") public int isApproved;
    }
}

// ── Orders ────────────────────────────────────────────────────────
class OrdersResponse {
    public boolean success;
    public List<Order> orders;
    public String message;
}

class Order {
    public int id;
    @SerializedName("order_code")    public String orderCode;
    @SerializedName("order_number")  public String orderNumber;
    public String status;
    @SerializedName("client_name")   public String clientName;
    @SerializedName("client_phone")  public String clientPhone;
    @SerializedName("pickup_address") public String pickupAddress;
    @SerializedName("delivery_address") public String deliveryAddress;
    @SerializedName("delivery_city") public String deliveryCity;
    @SerializedName("package_value") public double packageValue;
    @SerializedName("delivery_fee")  public double deliveryFee;
    @SerializedName("created_at")    public String createdAt;
    @SerializedName("has_otp")       public boolean hasOtp;
    public String notes;
}

// ── Live Updates ──────────────────────────────────────────────────
class LiveUpdatesResponse {
    public boolean success;
    @SerializedName("new_orders")     public List<Order> newOrders;
    @SerializedName("order_updates")  public List<OrderUpdate> orderUpdates;
    @SerializedName("notifications")  public List<Notification> notifications;
    @SerializedName("last_check")     public long lastCheck;

    public static class OrderUpdate {
        public int id;
        public String status;
        @SerializedName("order_code") public String orderCode;
    }
}

// ── Notifications ─────────────────────────────────────────────────
class NotificationsResponse {
    public boolean success;
    public NotifData data;

    public static class NotifData {
        public List<Notification> items;
        public int unread;
    }
}

class Notification {
    public int id;
    public String type;
    public String title;
    public String message;
    @SerializedName("created_at")     public String createdAt;
    @SerializedName("formatted_date") public String formattedDate;
    @SerializedName("is_read")        public boolean isRead;
    @SerializedName("order_id")       public int orderId;
    @SerializedName("icon_class")     public String iconClass;
}

// ── Track Order ───────────────────────────────────────────────────
class TrackOrderResponse {
    public boolean success;
    public TrackData data;
    public String message;

    public static class TrackData {
        @SerializedName("order_code")    public String orderCode;
        public String status;
        @SerializedName("distributor_name") public String distributorName;
        @SerializedName("distributor_phone") public String distributorPhone;
        public double lat;
        public double lng;
    }
}
